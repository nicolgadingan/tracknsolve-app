# yortik-app
Yortik is a basic incident management application that is built with Laravel.

## Credits
**Icons** by [kmgdesignid](https://www.iconfinder.com/kmgdesignid)

**Icons** by [rudymuhardika](https://www.iconfinder.com/rudymuhardika)