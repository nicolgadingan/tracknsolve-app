<div class="">
    <a href="<?php echo e($path); ?>" class="display-6 link-secondary">
        <i class="bi bi-arrow-left-square-fill"></i>
    </a>
    
</div><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/plugins/previous.blade.php ENDPATH**/ ?>