

<?php $__env->startSection('page'); ?>
    Tickets
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tickets-index')->html();
} elseif ($_instance->childHasBeenRendered('Yr4D7mv')) {
    $componentId = $_instance->getRenderedChildComponentId('Yr4D7mv');
    $componentTag = $_instance->getRenderedChildComponentTagName('Yr4D7mv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Yr4D7mv');
} else {
    $response = \Livewire\Livewire::mount('tickets-index');
    $html = $response->html();
    $_instance->logRenderedChild('Yr4D7mv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/tickets/index.blade.php ENDPATH**/ ?>