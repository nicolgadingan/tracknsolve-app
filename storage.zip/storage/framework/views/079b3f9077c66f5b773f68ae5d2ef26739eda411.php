

<?php $__env->startSection('page'); ?>
    View Incident
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $access =   auth()->user();
?>
<div class="container" id="tk-create-box">
    <div class="card card-body border-round borderless shadow-sm pt-4">
        <div class="mb-2">
            <?php if($ticket->group_id == $access->group_id &&
                                $ticket->assignee == ''): ?>
                <form action="/tickets/<?php echo e($ticket->tkey); ?>/get" method="POST" id="tk-assigntome-form" class="d-none">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                </form>
                <script>
                    $(document).ready(function() {
                        $("body").on("click", "#tk-assigntome", function() {
                            event.preventDefault();
                            $("#tk-assigntome-form").submit();
                        })
                    });
                </script>
            <?php endif; ?>
            <?php if($ticket->status == 'in-progress' &&
                    $ticket->assignee == $access->id): ?>
                <form method="POST" action="/tickets/<?php echo e($ticket->tkey); ?>/resolve" id="tk-resolve-form" class="d-none">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                </form>
                <script>
                    $(document).ready(function() {
                        $("body").on("click", "#tk-resolve-ticket", function() {
                            event.preventDefault();
                            $("#tk-resolve-form").submit();
                        });
                    });
                </script>
            <?php endif; ?>
            <form method="POST" action="/tickets/<?php echo e($ticket->tkey); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-4 d-flex justify-content-between">
                    <?php if ($__env->exists('plugins.previous', ['path' => '/tickets'])) echo $__env->make('plugins.previous', ['path' => '/tickets'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="d-flex">
                        <?php if($ticket->status == 'in-progress' &&
                                $ticket->assignee == $access->id): ?>
                            <div class="mr-3">
                                <button type="button" class="btn btn-lg btn-outline-secondary shadow" id="tk-resolve-ticket">
                                    Resolve
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if($ticket->group_id == $access->group_id &&
                                $ticket->assignee == ''): ?>
                            <div class="mr-3">
                                <button type="button" class="btn btn-lg btn-outline-secondary" id="tk-assigntome">
                                    Get
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if($ticket->status != 'closed'): ?>
                            <button type="submit" class="btn btn-marine btn-lg shadow" id="tk-update-submit">
                                Update
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h6 class="fg-forest">STATUS</h6>
                <div class="row g-3">
                    <div class="col-md">
                        <div class="form-floating mb-3">
                            <input type="text" name="tkey" class="form-control" id="tk-tkey" value="<?php echo e($ticket->tkey); ?>" readonly wire:model="tkey">
                            <label for="tk-tkey">Key</label>
                        </div>
                    </div>
                    <div class="col-md right">
                        <div class="mb-2 right">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="tk-upd-created-at" value="<?php echo e($ticket->ticket_created); ?>" readonly>
                                <label for="tk-upd-created-at">Create Date</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-3 g-3">
                    <div class="col-md">
                        <?php if($ticket->status == 'resolved' || $ticket->status == 'closed'): ?>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="tk-resolved-date" value="<?php echo e($ticket->resolved_at); ?>"
                                    placeholder="Resolved Date" readonly>
                                <label for="tk-resolved-date">Resolved Date</label>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md">
                        <?php if($ticket->status == 'closed'): ?>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="tk-closed-date" value="<?php echo e($ticket->closed_at); ?>"
                                    placeholder="Closed Date" readonly>
                                <label for="tk-closed-date">Closed Date</label>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <h6 class="fg-forest">REPORTER</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="hidden" name="caller" value="<?php echo e($ticket->reporter); ?>">
                            <input type="text" class="form-control" id="tk-upd-username" value="<?php echo e($ticket->user->username); ?>" readonly>
                            <label for="tk-username">Reporter</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="tk-upd-fullname" value="<?php echo e($ticket->user->first_name . ' ' . $ticket->user->last_name); ?>" readonly>
                            <label for="tk-fullname">Name</label>
                        </div>
                    </div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="tk-upd-email" value="<?php echo e($ticket->user->email); ?>" readonly>
                            <label for="tk-email">Email</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="tk-upd-group" value="<?php echo e($ticket->user->group->name); ?>" readonly>
                            <label for="tk-group">Group</label>
                        </div>
                    </div>
                </div>
                <h6 class="fg-forest">TICKET</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <select name="priority" id="tk-upd-priority" wire:model="priority" class="form-select <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                <?php if($ticket->status == 'closed'): ?> disabled <?php endif; ?>>
                                <option value="urgent" <?php echo e(( $ticket->priority == 'urgent' ) ? 'selected' : ''); ?>>Urgent</option>
                                <option value="important" <?php echo e(( $ticket->priority == 'important' ) ? 'selected' : ''); ?>>Important</option>
                                <option value="task" <?php echo e(( $ticket->priority == 'task' ) ? 'selected' : ''); ?>>Task</option>
                                <option value="request" <?php echo e(( $ticket->priority == 'request' ) ? 'selected' : ''); ?>>Request</option>
                            </select>
                            <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="tk-priority">Priority</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <select name="status" id="tk-upd-status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="status"
                                <?php if($ticket->status == 'closed'): ?> disabled <?php endif; ?>>
                                
                                <?php if($ticket->status == 'closed'): ?>
                                    <option value="closed" <?php echo e(( $ticket->status == 'closed' ) ? 'selected' : ''); ?>>Closed</option>
                                <?php else: ?>
                                    <?php if(old('status') == '' || old('status') == null): ?>
                                        <option value="new" <?php echo e(( $ticket->status == 'new' ) ? 'selected' : ''); ?>>New</option>
                                        <option value="in-progress" <?php echo e(( $ticket->status == 'in-progress' ) ? 'selected' : ''); ?>>In Progress</option>
                                        <option value="on-hold" <?php echo e(( $ticket->status == 'on-hold' ) ? 'selected' : ''); ?>>On Hold</option>
                                        <option value="resolved" <?php echo e(( $ticket->status == 'resolved' ) ? 'selected' : ''); ?>>Resolved</option>
                                    <?php else: ?>
                                        <option value="new" <?php echo e(( old('status') == 'new' ) ? 'selected' : ''); ?>>New</option>
                                        <option value="in-progress" <?php echo e(( old('status') == 'in-progress' ) ? 'selected' : ''); ?>>In Progress</option>
                                        <option value="on-hold" <?php echo e(( old('status') == 'on-hold' ) ? 'selected' : ''); ?>>On Hold</option>
                                        <option value="resolved" <?php echo e(( old('status') == 'resolved' ) ? 'selected' : ''); ?>>Resolved</option>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="tk-status">Status</label>
                        </div>
                    </div>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tickets-edit', [
                    'group'     =>  $ticket->group_id,
                    'assignee'  =>  $ticket->assignee,
                    'status'    =>  $ticket->status
                ])->html();
} elseif ($_instance->childHasBeenRendered('9iJ6BaX')) {
    $componentId = $_instance->getRenderedChildComponentId('9iJ6BaX');
    $componentTag = $_instance->getRenderedChildComponentTagName('9iJ6BaX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9iJ6BaX');
} else {
    $response = \Livewire\Livewire::mount('tickets-edit', [
                    'group'     =>  $ticket->group_id,
                    'assignee'  =>  $ticket->assignee,
                    'status'    =>  $ticket->status
                ]);
    $html = $response->html();
    $_instance->logRenderedChild('9iJ6BaX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <h6 class="fg-forest">DETAILS</h6>
                <div class="row mb-3">
                    <div class="col">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title"
                                placeholder="Title" value="<?php echo e($ticket->title); ?>" maxlength="100" wire:model.debounce.1000ms="title"
                                <?php echo e(( $access->group_id != $ticket->user->group_id ) ? 'readonly' : ''); ?> <?php if($ticket->status == 'closed'): ?> disabled <?php endif; ?>>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="title">Title</label>
                        </div>
                        <div class="form-floating mb-3">
                            <textarea name="description" id="tk-upd-description" cols="30" rows="20"
                                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.debounce.1000ms="description"
                                placeholder="Type the ticket description here.." style="min-height: 147px;" maxlength="4000"
                                <?php echo e(( $access->group_id != $ticket->user->group_id ) ? 'readonly' : ''); ?>

                                <?php if($ticket->status == 'closed'): ?> disabled <?php endif; ?>><?php echo $ticket->description; ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="tk-description">Description</label>
                        </div>
                    </div>
                </div>
                <div class="mb-3" hidden>
                    <?php echo e($ticket); ?> <br>
                    <?php echo e($errors); ?>

                </div>
            </form>
        </div>
        <div class="mb-2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('upload-attachment', [
                    'tkey'      =>  $ticket->tkey,
                    'status'    =>  $ticket->status
                ])->html();
} elseif ($_instance->childHasBeenRendered('ilekrs5')) {
    $componentId = $_instance->getRenderedChildComponentId('ilekrs5');
    $componentTag = $_instance->getRenderedChildComponentTagName('ilekrs5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ilekrs5');
} else {
    $response = \Livewire\Livewire::mount('upload-attachment', [
                    'tkey'      =>  $ticket->tkey,
                    'status'    =>  $ticket->status
                ]);
    $html = $response->html();
    $_instance->logRenderedChild('ilekrs5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="mb-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tickets-comments', [
                    'tkey'      =>  $ticket->tkey,
                    'status'    =>  $ticket->status
                ])->html();
} elseif ($_instance->childHasBeenRendered('Fc6yZMI')) {
    $componentId = $_instance->getRenderedChildComponentId('Fc6yZMI');
    $componentTag = $_instance->getRenderedChildComponentTagName('Fc6yZMI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Fc6yZMI');
} else {
    $response = \Livewire\Livewire::mount('tickets-comments', [
                    'tkey'      =>  $ticket->tkey,
                    'status'    =>  $ticket->status
                ]);
    $html = $response->html();
    $_instance->logRenderedChild('Fc6yZMI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/tickets/edit.blade.php ENDPATH**/ ?>