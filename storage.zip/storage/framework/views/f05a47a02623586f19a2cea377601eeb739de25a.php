<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="form-floating mb-3">
            <select name="group" id="tk-upd-assignment" class="form-select <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Group name" wire:model="group" <?php if($status == 'closed'): ?> disabled <?php endif; ?>>
                <?php if(count($groups) > 0): ?>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($grp->id); ?>"><?php echo e($grp->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="tk-assignment" class="form-label">Assignment Group</label>
        </div>
    </div>
    <div class="col-md-6" style="position: relative;">
        <div class="form-floating mb-1">
            <select name="assignee" wire:model="assignee" id="tk-upd-assignee"
                class="form-select <?php $__errorArgs = ['assignee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php if($status == 'closed'): ?> disabled <?php endif; ?>>
                <?php if(count($users) > 0): ?>
                    <option value="">Select Assignee (optional)</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->user_id); ?>"><?php echo e($user->first_name . ' ' . $user->last_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <?php $__errorArgs = ['assignee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="tk-assignee">Assignee</label>
        </div>
        <div class="mb-3" hidden>
            <?php echo e('Group: ' . $group); ?>

            <br>
            <?php echo e('Assignee: ' . $assignee); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/tickets-edit.blade.php ENDPATH**/ ?>