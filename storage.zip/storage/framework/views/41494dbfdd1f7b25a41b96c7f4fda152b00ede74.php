<div>
    <?php
        $uinf   =   auth()->user();
    ?>

    <div class="row g-3 mb-4">
        <div class="col-md">
            <div class="search" style="max-width: 300px;">
                <input type="text" class="form-control search-input borderless" placeholder="Search..."
                    name="" wire:model="searchgroup">
            </div>
        </div>
        <div class="col-md right">
            <?php if(auth()->user()->role == "admin"): ?>
                <button class="btn btn-marine" data-bs-toggle="modal" data-bs-target="#gr-new-group-form">New Group</button>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col">
            <div class="card card-body border-round borderless shadow-sm p-0">
                <table class="table table-borderless table-hover">
                    <thead class="bg-marine-dark fg-white">
                        <th class="pt-3">Name</th>
                        <th>Status</th>
                        <th>Manager</th>
                        <th>Members</th>
                        <th class="right">Created</th>
                        <?php if($uinf->role == 'admin'): ?>
                            <th></th>
                        <?php endif; ?>
                    </thead>
                    <tbody>
                        <?php echo e($data); ?>

                        <?php if(count($data) > 0): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td>
                                        <a href="/groups/<?php echo e($group->id); ?>" class="link-marine">
                                            <b><?php echo e($group->name); ?></b>
                                        </a>
                                    </td>
                                    <td>
                                        <?php
                                            $status =   '';
                                            $theme  =   '';

                                            switch ($group->status) {
                                                case 'A':
                                                    $status =   'Active';
                                                    $theme  =   'success';
                                                    break;
                                                case 'I':
                                                    $status =   'Inactive';
                                                    $theme  =   'secondary';
                                                    break;
                                                default:
                                                    $theme  =   'secondary';
                                                    break;
                                            }
                                        ?>
                                        <span class="dot dot-<?php echo e($theme); ?>">
                                            <?php echo e($status); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="/users/<?php echo e($group->manager->id); ?>" class="link-marine">
                                            <?php echo e($group->manager->first_name . ' ' . $group->manager->last_name); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e(count($group->members)); ?>

                                    </td>
                                    <td class="right">
                                        <?php echo e(\Carbon\Carbon::create($group->created_at)->diffForHumans()); ?>

                                    </td>
                                    <?php if($uinf->role == 'admin'): ?>
                                        <td class="right">
                                            <?php if($status == 'Active'): ?>
                                                <a href="#deac-<?php echo e($group->slug); ?>" class="link-success gr-deactivate mr-1" data-value="<?php echo e($group->id); ?>"
                                                    data-bs-toggle="tooltip" data-bs-placement="left" title="Group is Active.<br>Click to deactivate."
                                                    data-bs-html="true">
                                                    <i class="bi bi-toggle-on fs-lg"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="#acti-<?php echo e($group->slug); ?>" class="link-secondary gr-activate mr-1" data-value="<?php echo e($group->id); ?>"
                                                    data-bs-toggle="tooltip" data-bs-placement="left" title="Group is Inactive.<br> Click to activate."
                                                    data-bs-html="true">
                                                    <i class="bi bi-toggle-off fs-lg"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <a href="#delete-<?php echo e($group->slug); ?>" class="link-danger gr-delete" data-value="<?php echo e($group->id); ?>"
                                                data-bs-toggle="tooltip" data-bs-placement="left" title="Delete group" aria-label="<?php echo e($group->name); ?>">
                                                <i class="bi bi-trash-fill fs-lg"></i>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">
                                    No Groups found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="p-3 pt-0 d-flex justify-content-between">
                    <span class="fg-forest">
                        <?php echo e('Showing ' . $data->total() . ' groups'); ?>

                    </span>
                    <span>
                        <?php echo e($data->links()); ?>

                    </span>
                </div>
            </div>
        </div>
        <form action="" method="POST" id="gr-deac-form" class="d-none">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        </form>
        <form action="" method="post" id="gr-acti-form" class="d-none">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        </form>
    </div>
    <div class="p-3 mb-3" hidden>
        <?php echo e('Searching: ' . $searchgroup); ?>

        <br>
        <?php echo e('Count: ' . count($data)); ?>

        <br>
        <?php echo e('Groups: ' . $data); ?>

    </div>
</div>

<script>
    $(document).ready(function() {

        // Deactivate group
        $("body").on("click", ".gr-deactivate", function() {
            var form    =   $("#gr-deac-form"),
                grpId   =   $(this).data("value");

            event.preventDefault();

            form.attr("action", "/groups/" + grpId + "/deactivate");
            form.submit();

        });

        // Activate group
        $("body").on("click", ".gr-activate", function() {
            var form    =   $("#gr-acti-form"),
                grpId   =   $(this).data("value");

            event.preventDefault();

            form.attr("action", "/groups/" + grpId + "/activate");
            form.submit();

        });

        // Delete group
        $("body").on("click", ".gr-delete", function() {
            var modal   =   $("#gr-delt-group-modal"),
                title   =   $("#gr-delt-group-modal #gr-delt-group-label"),
                nameEl  =   $("#gr-delt-group-modal #gr-delt-name"),
                grpId   =   $(this).data("value"),
                grpName =   $(this).attr("aria-label"),
                grpForm =   $("#gr-delt-group-form");

            event.preventDefault();

            grpForm.attr("action", "/groups/" + grpId);
            title.text("Deleting " + grpName);
            nameEl.text(grpName);

            modal.modal("show");

        });
    });
</script><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/groups-index.blade.php ENDPATH**/ ?>