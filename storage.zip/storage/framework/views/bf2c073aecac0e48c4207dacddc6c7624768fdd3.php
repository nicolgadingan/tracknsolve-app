

<?php $__env->startSection('page'); ?>
    Verify Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center">
    <div class="card card-body borderless shadow-sm border-bubble pb-2" id="box-login">
        <div class="center mb-3 p-2">
            <img src="<?php echo e(asset('imgs/yortik.svg')); ?>" alt="Yortik logo" id="brand-auth">
        </div>
        <?php if($status != "not-exists"): ?>
            <?php if($status == "not-verified"): ?>
                <div class="alert alert-primary">
                    <div class="justify">
                        <?php echo $message; ?>

                    </div>
                </div>
                <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('verify')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating mb-3">
                        <input type="password" id="password" name="password" placeholder="Password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="new-password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="password">Password</label>
                    </div>
                    <div class="form-floating mb-4">
                        <input type="password" id="confirm-password" name="password_confirmation" placeholder="Confirm Password"
                            class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="new-password">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo $message; ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="confirm-password">Confirm Password</label>
                    </div>
                    <input type="hidden" value="<?php echo e($userid); ?>" name="user_id">
                    <div class="right">
                        <button type="submit" class="btn btn-lg btn-marine shadow">Submit</button>
                    </div>
                </form>
            <?php else: ?>
                <div class="alert alert-warning">
                    <div class="justify">
                        <?php echo $message; ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
        <div class="alert alert-warning">
            <div class="justify">
                <?php echo $message; ?>

            </div>
        </div>
        <?php endif; ?>
        <div class="pt-5 center">
            <small class="text-muted">
                v<?php echo e(config('app.ver')); ?>

            </small>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/accesses/verify.blade.php ENDPATH**/ ?>