

<?php $__env->startSection('page'); ?>
    Group <?php echo e($group->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('groups-edit', ['gid' => $group->id])->html();
} elseif ($_instance->childHasBeenRendered('Zet8zwu')) {
    $componentId = $_instance->getRenderedChildComponentId('Zet8zwu');
    $componentTag = $_instance->getRenderedChildComponentTagName('Zet8zwu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Zet8zwu');
} else {
    $response = \Livewire\Livewire::mount('groups-edit', ['gid' => $group->id]);
    $html = $response->html();
    $_instance->logRenderedChild('Zet8zwu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/groups/view.blade.php ENDPATH**/ ?>