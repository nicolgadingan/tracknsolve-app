<div class="form-floating mb-3">
    <input type="hidden" id="tk-selected-group" wire:model="group">
    <input type="text" class="form-control <?php $__errorArgs = ['assignee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="assignee"
        name="assignee" id="tk-assignee" list="tk-assignee-list">
    <datalist id="tk-assignee-list">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->username); ?>"><?php echo e($user->fullname); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </datalist>
    <?php $__errorArgs = ['assignee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback">
            <?php echo e($message); ?>

        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <label for="tk-assignee">Assignee</label>
    <?php echo e($group); ?>

</div><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/tickets-get-users.blade.php ENDPATH**/ ?>