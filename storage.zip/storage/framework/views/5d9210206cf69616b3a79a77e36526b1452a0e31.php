

<?php $__env->startSection('content'); ?>
    <div>
        <img height="100px" src="<?php echo e(asset('imgs/email-notice.svg')); ?>" alt="Yortik logo">
    </div>
    <span class="center" style="font-size: x-large;">Account Verified!</span><br><br> 
    <p>
        Thank you for verifying your account.
    </p>
    <p>
        Login to your account and start your journey with yortik. 
    </p>
    <div class="p-2">
        <a href="<?php echo e(Request::root()); ?>/login" class="link-button">
            Login
        </a>
    </div>
    <p>
        Forgot your username? It's <b><?php echo e($mailData->username); ?></b>.<br>
        You can keep this email for later.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/mails/verified.blade.php ENDPATH**/ ?>