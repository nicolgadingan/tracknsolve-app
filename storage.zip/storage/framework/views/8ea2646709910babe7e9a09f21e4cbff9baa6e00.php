<?php if(count($errors) > 0 && $errors->has('message')): ?>
    <div class="alert alert-danger p-2">
        <div class="d-flex align-items-start">
            <div class="pl-2 pr-2">
                <i class="bi bi-exclamation-diamond-fill fs-xl"></i>
            </div>
            <div class="fs-sm">
                <strong>Oopsy Daisy!</strong><br>
                <?php if($errors->has('message')): ?>
                    <?php echo $errors->first(); ?>

                <?php endif; ?>
            </div>
        </div>
        
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success fs-sm">
        <strong>Hooray!</strong>
        <?php echo session('success'); ?>

    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert alert-warning fs-sm">
        <strong>Holy Guacamole!</strong>
        <?php echo session('warning'); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger fs-sm">
        <strong>Oh Snap!</strong>
        <?php echo session('error'); ?>

    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/plugins/messages.blade.php ENDPATH**/ ?>