<div class="container-fluid">
    <?php
        $uinf    =   auth()->user();
    ?>
    <div class="d-flex justify-content-between mb-4">
        <div id="us-group-updates" class="d-flex">
            <div class="mr-3">
                <div class="search" style="max-width: 300px;">
                    <input type="text" class="form-control search-input borderless" placeholder="Search..."
                        name="user_search" id="us-search-user" wire:model="keyword">
                </div>
            </div>
            <div class="mr-3">
                <div class="has-icon has-icon-start">
                    <select class="form-select borderless border-round has-icon-form" wire:model="fltrRole">
                        <option value="">All</option>
                        <?php if(count($roles) > 0): ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->role); ?>"><?php echo e(Str::ucfirst($role->role)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <span class="has-icon-this">
                        <i class="bi bi-person-bounding-box fs-re"></i>
                    </span>
                </div>
            </div>
        </div>
        <div id="us-group-actions">
            <?php if($uinf->role == 'admin'): ?>
                <a href="/users/create" class="btn btn-marine shadow">
                    New User
                </a>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col">
            <div class="card card-body border-round p-0 shadow-sm">
                <table class="table table-hover table-borderless">
                    <thead class="fg-white bg-marine-dark">
                        <th class="pt-3">Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Group</th>
                        <th class="right">Joined</th>
                        <?php if($uinf->role == 'super'): ?>
                            <th></th>
                        <?php endif; ?>
                    </thead>
                    <tbody>
                        <?php if(count($users) > 0): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td>
                                        <a href="/users/<?php echo e($user->id); ?>" class="link-marine us-view-trigger">
                                            <strong>
                                                <?php echo e($user->first_name . ' ' . $user->last_name); ?>

                                            </strong>
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e(Str::ucfirst($user->role)); ?>

                                    </td>
                                    <td>
                                        <?php
                                            $status =   ($user->status == 'A') ? 'Active' : 'Inactive';
                                            switch ($status) {
                                                case 'Active':
                                                    $theme  =   'success';
                                                    break;
                                                default:
                                                    $theme  =   'secondary';
                                                    break;
                                            }
                                        ?>
                                        <span class="dot dot-<?php echo e($theme); ?>">
                                            <?php echo e($status); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="mailto:<?php echo e(str_replace('.', '@@', $user->email)); ?>" class="link-marine"
                                            onclick="this.href=this.href.replace('@@', '.')">
                                            <?php echo e($user->email); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e($user->username); ?>

                                    </td>
                                    <td>
                                        <?php echo e($user->group->name); ?>

                                    </td>
                                    <td class="right">
                                        <?php echo e(\Carbon\Carbon::create($user->created_at)->diffForHumans()); ?>

                                    </td>
                                    <?php if($uinf->role == 'super'): ?>
                                        <td class="right">
                                            <a href="#delete-<?php echo e($user->slug); ?>" class="link-danger fs-lg us-del-user" data-value="<?php echo e($user->id); ?>"
                                                aria-label="<?php echo e($user->first_name . ' ' . $user->last_name); ?>" data-bs-toggle="tooltip" data-bs-placement="left"
                                                title="Delete user">
                                                <i class="bi bi-trash-fill"></i>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8">
                                    No users found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="p-3 pt-0 d-flex justify-content-between">
                    <span class="fg-forest">
                        <?php
                            $_tail   =   ($users->total() > 1) ? 's' : '';
                        ?>
                        <?php echo e('Showing ' . $users->total() . ' user' . $_tail); ?>

                    </span>
                    <span>
                        <?php echo e($users->links()); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    $(document).ready(function() {
        $("body").on("click", ".us-del-user", function() {
            var userId  =   $(this).data("value"),
                userNm  =   $(this).attr("aria-label"),
                modal   =   $("#us-delt-user-modal"),
                label   =   $("#us-delt-user-label"),
                uName   =   $("#us-delt-user-name"),
                uForm   =   $("#us-delt-user-form");

            label.text("Deleting " + userNm);
            uName.text(userNm);
            uForm.attr("action", "/groups/" + userId);

            modal.modal("show");
        });
    });
</script><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/users-search-user.blade.php ENDPATH**/ ?>