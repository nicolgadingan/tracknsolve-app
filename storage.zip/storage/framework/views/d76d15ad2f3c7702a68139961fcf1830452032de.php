

<?php $__env->startSection('page'); ?>
    Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluids">
    This is your Settings page
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/settings/index.blade.php ENDPATH**/ ?>