<div>
    <div class="d-flex align-items-center mb-2">
        <h6 class="fg-forest mb-0">
            COMMENTS
        </h6>
        <span class="badge bg-cheese fg-marine fs-sm ml-2">
            <?php echo e(count($comments)); ?>

        </span>
    </div>
    <?php if($status != 'closed'): ?>
        <div class="mb-3">
            <form wire:submit.prevent="postComment">
                <div class="row g-3">
                    <div class="col-md">
                        <textarea name="comment" id="tk-comment" cols="30" rows="2" placeholder="Type your comment here..."
                            class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="comment"></textarea>
                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback">
                                <?php echo e($message); ?>

                            </span>                
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-auto align-self-end">
                        <button class="btn btn-primary" type="submit">Post</button>
                    </div>
                </div>
            </form>
        </div>
    <?php endif; ?>
    <ul class="list-group fs-sm">
        <?php if(count($comments) > 0): ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item list-group-item-action">
                    <div class="d-flex justify-content-between">
                        <a href="/users/<?php echo e($comment->user->id); ?>" class="link-primary">
                            <strong>
                                <?php echo e($comment->user->first_name . ' ' . $comment->user->last_name); ?>

                            </strong>
                        </a>
                        <span><?php echo e(\Carbon\Carbon::create($comment->created_at)->diffForHumans()); ?></span>
                    </div>
                    <pre class="fs-sm"><?php echo e($comment->comments); ?></pre>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <li class="list-group-item">
                <i>No comments found.</i>
            </li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/tickets-comments.blade.php ENDPATH**/ ?>