

<?php $__env->startSection('page'); ?>
    <?php echo e($user->first_name . ' ' . $user->last_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card card-body border-round border-forest-light pt-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('users-edit', ['user' =>  $user])->html();
} elseif ($_instance->childHasBeenRendered('hiTm8yt')) {
    $componentId = $_instance->getRenderedChildComponentId('hiTm8yt');
    $componentTag = $_instance->getRenderedChildComponentTagName('hiTm8yt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hiTm8yt');
} else {
    $response = \Livewire\Livewire::mount('users-edit', ['user' =>  $user]);
    $html = $response->html();
    $_instance->logRenderedChild('hiTm8yt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/users/show.blade.php ENDPATH**/ ?>