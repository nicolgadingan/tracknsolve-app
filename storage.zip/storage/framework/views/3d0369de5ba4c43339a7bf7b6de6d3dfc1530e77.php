

<?php $__env->startSection('page'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex">
            <div class="mb-3 flex-grow-1 pr-4">
                <div class="p-3 pb-2">
                    <span class="fg-marine fs-sm">UNASSIGNED TICKETS</span>
                </div>
                <div class="card card-body mb-4 borderless border-round p-0 shadow-sm">
                    <table class="table table-borderless table-hover">
                        <thead class="fg-white bg-marine-dark">
                            <th class="pt-3">Key</th>
                            <th>Priority</th>
                            <th>Title</th>
                            <th>Reporter</th>
                            <th class="right">Created</th>
                        </thead>
                        <tbody>
                            <?php if(count($gpUnassigned) > 0): ?>
                                <?php $__currentLoopData = $gpUnassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unassigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong>
                                                <a href="/tickets/<?php echo e($unassigned->tkey); ?>/edit" class="link-marine"><?php echo e($unassigned->tkey); ?></a>
                                            </strong>
                                        </td>
                                        <td>
                                            <?php echo e(Str::ucfirst($unassigned->priority)); ?>

                                        </td>
                                        <td>
                                            <?php echo e($unassigned->title); ?>

                                        </td>
                                        <td>
                                            <a href="/users/<?php echo e($unassigned->user->id); ?>" class="link-marine">
                                                <?php echo e($unassigned->user->first_name . ' ' . $unassigned->user->last_name); ?>

                                            </a>
                                        </td>
                                        <td class="right">
                                            <?php echo e(\Carbon\Carbon::create($unassigned->created_at)->diffForHumans()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">
                                        No unassigned tickets.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="p-3 pt-0 d-flex justify-content-between">
                        <span class="fg-forest">
                            <?php if(count($gpUnassigned) > 0): ?>
                                <?php echo e('Showing ' . $gpUnassigned->total() . ' tickets'); ?>

                            <?php endif; ?>
                        </span>
                        <span>
                            <?php echo e($gpUnassigned->links()); ?>

                        </span>
                    </div>
                </div>
                <div class="p-3 pb-2">
                    <span class="fg-marine fs-sm">MY TICKETS</span>
                </div>
                <div class="card card-body border-round borderless p-0 shadow-sm">
                    <table class="table table-borderless table-hover">
                        <thead class="bg-marine-dark fg-white">
                            <th class="pt-3">Key</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Description</th>
                            <th>Reporter</th>
                            <th class="right">Created</th>
                        </thead>
                        <tbody>
                            <?php if(count($myTickets) > 0): ?>
                                <?php $__currentLoopData = $myTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mytk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong>
                                                <a href="/tickets/<?php echo e($mytk->tkey); ?>/edit" class="link-marine"><?php echo e($mytk->tkey); ?></a>
                                            </strong>
                                        </td>
                                        <td>
                                            <?php echo e(Str::ucfirst($mytk->priority)); ?>

                                        </td>
                                        <td>
                                            <?php
                                                $theme  =   '';
                                                $tkstat =   ucwords(Str::replace('-', ' ', $mytk->status));
                                                switch ($mytk->status) {
                                                    case 'new':
                                                        $theme  =   'primary';
                                                        break;
                                                    case 'in-progress':
                                                        $theme  =   'warning';
                                                        break;
                                                    case 'on-hold':
                                                        $theme  =   'secondary';
                                                        break;
                                                    case 'resolved':
                                                        $theme  =   'success';
                                                        break;
                                                    default:
                                                        $theme  =   'secondary';
                                                        break;
                                                }
                                            ?>
                                            <span class="dot dot-<?php echo e($theme); ?>">
                                                <?php echo e($tkstat); ?>

                                            </span>
                                        </td>
                                        <td data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e($mytk->title); ?>">
                                            <?php if(Str::length($mytk->title) > 100): ?>
                                                <?php echo e(Str::substr($mytk->title, 0, 100) . '...'); ?>

                                            <?php else: ?>
                                                <?php echo e($mytk->title); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="/users/<?php echo e($mytk->user->id); ?>" class="link-marine">
                                                <?php echo e($mytk->user->first_name . ' ' . $mytk->user->last_name); ?>

                                            </a>
                                        </td>
                                        <td class="right">
                                            <?php echo e(\Carbon\Carbon::create($mytk->created_at)->diffForHumans()); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6">
                                        No tickets assigned to you.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="p-3 pt-0 d-flex justify-content-between">
                        <span class="fg-forest">
                            <?php if(count($myTickets) > 0): ?>
                                <?php echo e('Showing ' . $myTickets->total() . ' tickets'); ?>

                            <?php endif; ?>
                        </span>
                        <span>
                            <?php echo e($myTickets->links()); ?>

                        </span>
                    </div>
                </div>
            </div>
            <div style="width: 25%; max-width: 350px;" class="pl-2">
                <div class="p-3 pb-2">
                    <span class="fg-marine fs-sm">TICKETS BREAKDOWN</span>
                </div>
                <div class="card card-body border-round borderless shadow-sm" id="db-ticket-chart">
                    <canvas id="dbTicketsBreakdown" width="300" height="300" role="img"></canvas>
                    <div class="p-2 center">
                        <span class="fs-xl fg-dark">
                            <?php echo e(array_sum($chartData['counts'])); ?>

                        </span><br>
                        <span>OVERALL</span>
                    </div>
                    <script>
                        const ctx   =   document.getElementById("dbTicketsBreakdown").getContext("2d");
                        const dbtb  =   new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                labels: <?php echo json_encode($chartData['labels'], JSON_HEX_TAG); ?>,
                                datasets: [{
                                    label: 'Tickets Breakdown',
                                    data: <?php echo json_encode($chartData['counts'], JSON_HEX_TAG); ?>,
                                    backgroundColor: <?php echo json_encode($chartData['colors'], JSON_HEX_TAG); ?>,
                                    borderColor: <?php echo json_encode($chartData['colors'], JSON_HEX_TAG); ?>,
                                    borderWidth: 1,
                                    hoverOffset: 3,
                                }]
                            },
                            options: {
                                layout: {
                                    padding: {
                                        top: 5,
                                        right: 5,
                                        bottom: 5,
                                        left: 5
                                    }
                                },
                                plugins: {
                                    legend: {
                                        display: false
                                    },
                                    title: {
                                        display: false,
                                        text: 'All Tickets'
                                    }
                                }
                            }
                            
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/dashboard.blade.php ENDPATH**/ ?>