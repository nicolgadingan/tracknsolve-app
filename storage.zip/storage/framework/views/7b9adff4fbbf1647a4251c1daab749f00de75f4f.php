

<?php $__env->startSection('page'); ?>
    Groups
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('groups-index')->html();
} elseif ($_instance->childHasBeenRendered('46RF71L')) {
    $componentId = $_instance->getRenderedChildComponentId('46RF71L');
    $componentTag = $_instance->getRenderedChildComponentTagName('46RF71L');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('46RF71L');
} else {
    $response = \Livewire\Livewire::mount('groups-index');
    $html = $response->html();
    $_instance->logRenderedChild('46RF71L', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    
    <div class="modal fade" id="gr-new-group-form" tabindex="-1" aria-labelledby="gr-new-group-label"
        aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-round">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('groups-create', ['managers' => $managers])->html();
} elseif ($_instance->childHasBeenRendered('IG8GeKx')) {
    $componentId = $_instance->getRenderedChildComponentId('IG8GeKx');
    $componentTag = $_instance->getRenderedChildComponentTagName('IG8GeKx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IG8GeKx');
} else {
    $response = \Livewire\Livewire::mount('groups-create', ['managers' => $managers]);
    $html = $response->html();
    $_instance->logRenderedChild('IG8GeKx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="gr-delt-group-modal" tabindex="-1" aria-labelledby="gr-delt-group-label"
        aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="gr-delt-group-form" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <div class="d-flex justify-content-between p-3 align-items-center">
                        <h5 class="modal-title" id="gr-delt-group-label"></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="p-4 pt-0 fs-re fg-danger">
                        Deleted groups will not be recovered. <br>
                        Are you sure you want to proceed deleting <b id="gr-delt-name"></b>?
                    </div>
                    <div class="mb-1 p-4 pt-0 right">
                        <button type="button" class="btn btn-light mb-2 mr-2" data-bs-dismiss="modal" aria-label="Close">
                            Cancel
                        </button>
                        <?php if(auth()->user()->role == "admin"): ?>
                            <button type="submit" class="btn btn-danger shadow-sm mb-2">
                                Delete
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/groups/index.blade.php ENDPATH**/ ?>