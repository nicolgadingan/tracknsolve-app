<form wire:submit.prevent="submitData">
    <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h6 class="fg-forest">STATUS</h6>
    <div class="row mb-3">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input type="text" name="tkey" class="form-control" id="tk-tkey" value="<?php echo e($tkey); ?>" readonly>
                <label for="tk-tkey">Key</label>
            </div>
        </div>
        <div class="col-md-6 right">
            <div class="mb-2 right">
                <button type="submit" class="btn btn-marine btn-lg" id="tk-create-submit">
                    Submit
                </button>
            </div>
        </div>
    </div>
    <h6 class="fg-forest">REPORTER</h6>
    <div class="row g-3">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input type="hidden" name="reporter" value="<?php echo e($user->id); ?>" wire:model="reporter">
                <input type="text" class="form-control" id="tk-username" value="<?php echo e($user->username); ?>" readonly>
                <label for="tk-username">Reporter</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="tk-fullname" value="<?php echo e($user->first_name . ' ' . $user->last_name); ?>" readonly>
                <label for="tk-fullname">Name</label>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-2">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="tk-email" value="<?php echo e($user->email); ?>" readonly>
                <label for="tk-email">Email</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="tk-group" value="<?php echo e($user->group->name); ?>" readonly>
                <label for="tk-group">Group</label>
            </div>
        </div>
    </div>
    <h6 class="fg-forest">TICKET</h6>
    <div class="row g-3">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <select name="priority" id="tk-priority" wire:model="priority" class="form-select <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Select Priority</option>
                    <option value="urgent" <?php echo e(($priority == 'urgent') ? 'selected' : ''); ?>>Urgent</option>
                    <option value="important" <?php echo e(($priority == 'important') ? 'selected' : ''); ?>>Important</option>
                    <option value="task" <?php echo e(($priority == 'task') ? 'selected' : ''); ?>>Task</option>
                    <option value="request" <?php echo e(($priority == 'request') ? 'selected' : ''); ?>>Request</option>
                </select>
                <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="tk-priority">Priority</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <select name="status" id="tk-status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" <?php echo e(($ticket == null) ? 'disabled' : ''); ?> wire:model="status">
                    <option value="new" <?php echo e(($ticket == null) ? 'selected' : ''); ?>>New</option>
                    <option value="in-progress">In Progress</option>
                    <option value="pending">Pending</option>
                    <option value="resolved">Resolved</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="tk-status">Status</label>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-2">
        <div class="col-md-6">
            <div class="form-floating mb-3">
                <select name="group" id="tk-assignment" class="form-select <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Group name" wire:model="group">
                    <?php if(count($groups) > 0): ?>
                        <option value="999">Select Assignment Group</option>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($grp->id); ?>"><?php echo e($grp->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="tk-assignment" class="form-label">Assignment Group</label>
            </div>
        </div>
        <div class="col-md-6" style="position: relative;">
            <div class="search">
                <div class="form-floating mb-1">
                    <select name="assignee" wire:model="assignee" id="tk-assignee" class="form-select <?php $__errorArgs = ['assignee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php if(count($users) > 0): ?>
                            <option value="">Select Assignee (optional)</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $udata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($udata->id); ?>"><?php echo e($udata->first_name . ' ' . $udata->last_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <?php $__errorArgs = ['assignee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="tk-assignee">Assignee</label>
                </div>
            </div>
        </div>
    </div>
    <h6 class="fg-forest">DETAILS</h6>
    <div class="row mb-2">
        <div class="col">
            <div class="form-floating mb-3">
                <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title"
                    placeholder="Title" value="<?php echo e(old('title')); ?>" maxlength="100" wire:model="title">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="title">Title</label>
            </div>
            <div class="form-floating mb-3">
                <textarea name="description" id="tk-description" cols="30" rows="20"
                    class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="description"
                    placeholder="Type the ticket description here.." style="min-height: 147px;" maxlength="4000"><?php echo old('description'); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="tk-description">Description</label>
            </div>
        </div>
    </div>
</form><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/tickets-processor.blade.php ENDPATH**/ ?>