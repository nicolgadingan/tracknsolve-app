<div class="container-fluid">
    <div class="d-flex justify-content-between mb-4">
        <div id="tk-group-updates" class="d-flex">
            <div class="mr-3">
                <div class="search" style="width: 300px;">
                    <input type="text" class="form-control search-input borderless" placeholder="Search..."
                        name="" id="tk-search-ticket" wire:model="search">
                </div>
            </div>
            <div class="mr-3">
                <div class="has-icon has-icon-start">
                    <select class="form-select borderless border-round has-icon-form" wire:model="filter">
                        <option value="">All</option>
                        <?php if(count($statuses) > 0): ?>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($filter->status); ?>"><?php echo e(Str::ucfirst($filter->status)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <span class="has-icon-this">
                        <i class="bi bi-clipboard-check fs-re"></i>
                    </span>
                </div>
            </div>
        </div>
        <div id="tk-group-actions">
            <a href="/tickets/create" class="btn btn-marine shadow">
                New Ticket
            </a>
        </div>
    </div>
    <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col">
            <div class="card card-body borderless border-round shadow-sm p-0" style="overflow-x: auto;">
                <table class="table table-borderless table-hover">
                    <thead class="bg-marine-dark fg-white">
                        <th class="pt-3">Key</th>
                        <th>Status</th>
                        <th>Priority</th>
                        <th>Title</th>
                        <th>Group</th>
                        <th>Assignee</th>
                        <th>Reporter</th>
                        <th class="right">Created</th>
                    </thead>
                    <tbody>
                        <?php if(count($tickets) > 0): ?>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="/tickets/<?php echo e($ticket->tkey); ?>/edit" class="link-marine">
                                            <strong><?php echo e($ticket->tkey); ?></strong>
                                        </a>
                                    </td>
                                    <td>
                                        <?php
                                            $theme      =   '';
                                            $tkstatus   =   ucwords(Str::replace('-', ' ', $ticket->status));
                                            switch ($ticket->status) {
                                                case 'new':
                                                    $theme  =   'primary';
                                                    break;
                                                case 'in-progress':
                                                    $theme  =   'warning';
                                                    break;
                                                case 'on-hold':
                                                    $theme  =   'purple';
                                                    break;
                                                case 'resolved':
                                                    $theme  =   'success';
                                                    break;
                                                case 'closed':
                                                    $theme  =   'dark';
                                                    break;
                                                default:
                                                    $theme  =   'secondary';
                                                    break;
                                            }
                                        ?>
                                        <span class="dot dot-<?php echo e($theme); ?>">
                                            <?php echo e(Str::ucfirst($ticket->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e(Str::ucfirst($ticket->priority)); ?>

                                    </td>
                                    <td class="td-break" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo e($ticket->title); ?>">
                                        <span>
                                            <?php if(Str::length($ticket->title) > 100): ?>
                                                <?php echo e(Str::substr($ticket->title, 0, 100) . '...'); ?>

                                            <?php else: ?>
                                                <?php echo e($ticket->title); ?>

                                            <?php endif; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e($ticket->group_name); ?>

                                    </td>
                                    <td>
                                        <?php
                                            if ($ticket->assignee_fn != null ||
                                                    $ticket->assignee_fn != '') {
                                                $assignee   =   $ticket->assignee_fn . ' ' . $ticket->assignee_ln;
                                            } else {
                                                $assignee   =   '';
                                            }
                                        ?>
                                        <a href="/users/<?php echo e($ticket->assignee_id); ?>" class="link-marine">
                                            <?php echo e($assignee); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="/users/<?php echo e($ticket->reporter_id); ?>" class="link-marine">
                                            <?php echo e($ticket->reporter_fn . ' ' . $ticket->reporter_ln); ?>

                                        </a>
                                    </td>
                                    <td class="right">
                                        <?php echo e(\Carbon\Carbon::create($ticket->created)->diffForHumans()); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8">
                                    No tickets found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="p-3 pt-0 d-flex justify-content-between">
                    <span class="fg-forest">
                        <?php echo e('Showing ' . $tickets->total() . ' tickets'); ?>

                    </span>
                    <span>
                        <?php echo e($tickets->links()); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/tickets-index.blade.php ENDPATH**/ ?>