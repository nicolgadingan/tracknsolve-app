<?php
    $role   =   auth()->user()->role;
?>
<form wire:submit.prevent="updateUser">
    <?php echo csrf_field(); ?>
    <div class="mb-4 d-flex justify-content-between">
        <?php echo $__env->make('plugins.previous', ['path'    =>  '/users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <?php if($role == "admin"): ?>
                <button type="submit" class="btn btn-marine btn-lg shadow" <?php echo e(( count($errors) > 0 || $isFresh == true ) ? 'disabled' : ''); ?>>
                    Update
                </button>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h6 class="fg-forest">ORGANIZATION</h6>
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="form-floating">
                <select name="group" id="us-group" class="form-select" wire:model="group_id"
                    <?php echo e(( $role != "admin" ) ? 'disabled' : ''); ?>>
                    <?php if(count($groups) > 0): ?>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>">
                                <?php echo e($group->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <option value="">No available group</option>
                    <?php endif; ?>
                </select>
                <label for="us-group">Group</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="col-md">
                <div class="form-floating">
                    <select name="role" id="us-edit-role" class="form-select" wire:model="role"
                        <?php echo e(( $role != "admin" ) ? 'disabled' : ''); ?>>
                        <option value="user" <?php echo e($role == 'user' ? 'selected' : ''); ?>>User</option>
                        <option value="manager" <?php echo e($role == 'manager' ? 'selected' : ''); ?>>Manager</option>
                        <option value="admin" <?php echo e($role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                    </select>
                    <label for="us-edit-role">Role</label>
                </div>
            </div>
        </div>
    </div>
    <h6 class="fg-forest">USER INFORMATION</h6>
    <div class="row g-3 mb-3">
        <div class="col-md-6">
            <div class="form-floating">
                <input type="text" class="form-control" name="username" id="us-edit-username"
                    maxlength="20" placeholder="Username" value="<?php echo e($username); ?>" disabled>
                <label for="us-edit-username">Username</label>
                <i class="bi bi-info-circle-fill info-icon hover" data-bs-toggle="tooltip" data-bs-placement="bottom"
                    title="Username is an identifier and cannot be modified.">
                </i>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating">
                <?php
                    $status_text    =   '';
                    switch ($user->status) {
                        case 'A':
                            $status_text    =   'Active';
                            break;
                        case 'I':
                            $status_text    =   'Inactive';
                            break;
                        case 'X':
                            $status_text    =   'Archived';
                            break;
                        default:
                            $stutus_text    =   'Unknown';
                            break;

                    }
                ?>
                <input type="text" class="form-control" name="status" id="us-edit-status"
                    maxlength="20" placeholder="Username" value="<?php echo e($status_text); ?>" disabled>
                <label for="us-edit-status">Username</label>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-3">
        <div class="col-md">
            <div class="form-floating">
                <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name"
                    id="us-edit-first-name" maxlength="50" placeholder="First name" value="<?php echo e($first_name); ?>" wire:model="first_name"
                    <?php echo e(( $role != "admin" ) ? 'disabled' : ''); ?>>
                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="us-edit-first-name">First Name</label>
            </div>
        </div>
        <div class="col-md">
            <div class="form-floating">
                <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name"
                    id="us-edit-last-name" maxlength="50" placeholder="Last name" value="<?php echo e($last_name); ?>" wire:model="last_name"
                    <?php echo e(( $role != "admin" ) ? 'disabled' : ''); ?>>
                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="us-edit-first-name">Last Name</label>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-md">
            <div class="form-floating">
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="us-edit-email"
                    maxlength="50" placeholder="Email" value="<?php echo e($email); ?>" disabled>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="us-edit-email">Email</label>
                <i class="bi bi-info-circle-fill info-icon hover" data-bs-toggle="tooltip" data-bs-placement="bottom"
                    title="Email is an identifier and cannot be modified.">
                </i>
            </div>
        </div>
        <div class="col-md">
            <div class="form-floating">
                <input type="text" class="form-control" name="contact_no" id="us-edit-contact-no" maxlength="20" placeholder="Contact No"
                    value="<?php echo e($contact_no); ?>" wire:model="contact_no" <?php echo e(( $role != "admin" ) ? 'disabled' : ''); ?>>
                <label for="us-edit-contact-no">Contact Number</label>
            </div>
        </div>
    </div>
</form><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/users-edit.blade.php ENDPATH**/ ?>