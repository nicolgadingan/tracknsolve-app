<form wire:submit.prevent="saveGroup">
    <div class="modal-header">
        <h5 class="modal-title" id="gr-new-group-label">New Group</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body" x-data="{ remain: 255 }" x-init="remain = $refs.descn.maxLength; chars = $refs.descn.value.length">
        <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="form-floating mb-3">
            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" placeholder="Gorup name"
                id="gr-new-name" wire:model.debounce.500ms="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="gr-new-name">Group Name</label>
        </div>
        <div class="form-floating">
            <textarea id="gr-new-description" cols="30" rows="20" class="form-control" maxlength="255" wire:model="descn"
                x-ref="descn" x-on:keyup="chars = $refs.descn.value.length; remain = $refs.descn.maxLength - chars"></textarea>
            <label for="gr-new-description">Description</label>
        </div>
        <div class="mb-3 pt-1 pl-2">
            <span x-html="remain"></span> characters left
        </div>
        <div class="form-floating">
            <select id="gr-new-manager" class="form-select <?php $__errorArgs = ['manager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="manager"
                aria-placeholder="Manager" <?php echo e(( count($managers) == 0 ) ? 'disabled' : ''); ?>>
                <?php if(count($managers) > 0): ?>
                    <option value="">Select Manager</option>
                    <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($manager->id); ?>"><?php echo e(ucwords($manager->first_name . ' ' . $manager->last_name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <option value="">No available manager</option>
                <?php endif; ?>
            </select>
            <?php $__errorArgs = ['manager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="gr-new-manager">Manager</label>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-marine btn-lg shadow-sm" <?php echo e(( count($errors) > 0 ) ? 'disabled' : ''); ?>>Submit</button>
    </div>
    <div hidden><?php echo e($errors); ?></div>
</form><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/groups-create.blade.php ENDPATH**/ ?>