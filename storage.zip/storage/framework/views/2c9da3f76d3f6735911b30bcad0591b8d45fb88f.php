

<?php $__env->startSection('page'); ?>
    Reports
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluids">
    This is your Reports page
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/reports/index.blade.php ENDPATH**/ ?>