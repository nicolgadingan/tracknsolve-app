<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Yortik')); ?> - <?php echo $__env->yieldContent('page'); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('imgs/yortik-icon.svg')); ?>" type="image/x-icon">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body class="d-flex" style="height: 100vh;">
    <main class="align-self-center" style="width: 100vw; height: 70vh;">
        <div >
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</body>
</html><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/layouts/auth.blade.php ENDPATH**/ ?>