<div class="card card-body borderless border-round shadow-sm pt-4">
    <?php
        $role   =   auth()->user()->role;
        $extra  =   $isEditable ? '' : 'disabled';
    ?>
    <form wire:submit.prevent="saveUpdate">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="d-flex justify-content-between mb-4">
            <?php if ($__env->exists('plugins.previous', ['path' => '/groups'])) echo $__env->make('plugins.previous', ['path' => '/groups'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(auth()->user()->role == "admin"): ?>
                <button type="submit" class="btn btn-marine btn-lg shadow-sm mb-2" <?php echo e(( count($errors) > 0 ) || !$hasUpdate ? 'disabled' : ''); ?>>
                    Update
                </button>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h6 class="fg-forest">GROUP DETAILS</h6>
        <div class="mb-4">
            <div class="form-floating mb-3">
                <input type="text" class="form-control <?php $__errorArgs = ['group_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="group_name"
                    placeholder="Gorup name" id="gr-edit-name" value="<?php echo e($group_name); ?>" <?php echo e($extra); ?> wire:model="group_name">
                <?php $__errorArgs = ['group_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="gr-edit-name">Group Name</label>
            </div>
            <div x-data="{ charrem: 255 }" class="mb-3" x-init="chars = $refs.descn.value.length; charrem = $refs.descn.maxLength - chars">
                <div class="form-floating">
                    <textarea id="gr-edit-descn" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        style="height: 92px;" <?php echo e($extra); ?> maxlength="255" x-ref="descn" wire:model.debounce.500ms="description"
                        x-on:keyup="chars = $refs.descn.value.length; charrem = $refs.descn.maxLength - chars"><?php echo e($description); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="gr-edit-descn">Description</label>
                </div>
                <div class="pt-1 ml-2">
                    <span x-html="charrem"></span> remaining characters
                </div>
            </div>
            <div class="form-floating">
                <select id="gr-new-manager" name="manager_id" class="form-select <?php $__errorArgs = ['manager_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    <?php echo e(( count($managers) == 0 ) ? 'disabled' : ''); ?> <?php echo e($extra); ?> wire:model="manager_id">
                    <?php if(count($managers) > 0): ?>
                        <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($manager->id); ?>">
                                <?php echo e(ucwords($manager->first_name . ' ' . $manager->last_name)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <option value="">No available manager</option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['manager_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="gr-new-manager">Manager</label>
            </div>
        </div>
        </form>
        <h6 class="fg-forest pt-2">MEMBERS</h6>
        <ul class="list-group mb-4">
            <?php if(count($members) > 0): ?>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if ($member->status == 'A') {
                            $ms_theme   =   'success';
                            $ms_tip     =   'active';
                        } else {
                            $ms_theme   =   'secondary';
                            $ms_tip     =   'inactive';
                        }
                        
                    ?>
                    <li class="list-group-item list-group-item-action">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <strong><?php echo e(ucwords($member->first_name . ' ' . $member->last_name)); ?></strong><br>
                                <span><?php echo e(ucwords($member->role)); ?></span>
                            </div>
                            <i class="bi-check-circle-fill fg-<?php echo e($ms_theme); ?>"
                                data-bs-toggle="tooltip" title="User account is <?php echo e($ms_tip); ?>." data-bs-placement="left"></i>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <li class="list-group-item list-group-item-action">
                    No members.
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/groups-edit.blade.php ENDPATH**/ ?>