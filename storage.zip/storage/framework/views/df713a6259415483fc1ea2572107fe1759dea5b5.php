

<?php $__env->startSection('page'); ?>
    New Group
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('plugins.previous', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card card-body border-round border-forest-light pt-4">
        <h6 class="fg-forest">GROUP INFORMATION</h6>
        <?php
            $user   =   auth()->user();
        ?>
        <form action="/groups/create" method="post">
            <?php echo csrf_field(); ?>
            <div class="row g-3 mb-3">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" name="name" class="form-control" id="gr-name" placeholder="Group Name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="gr-name">Group Name</label>
                    </div>
                </div>
                <div class="col-md">
                    <div class="form-floating">
                        <select name="manager" id="gr-manager" class="form-select">
                            <option value="<?php echo e($user->id); ?>"><?php echo e(ucwords($user->first_name . ' ' . $user->last_name)); ?></option>
                        </select>
                        <label for="gr-manager">Manager</label>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/groups/create.blade.php ENDPATH**/ ?>