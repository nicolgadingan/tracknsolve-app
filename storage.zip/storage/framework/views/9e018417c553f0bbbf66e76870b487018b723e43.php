

<?php $__env->startSection('content'); ?>
    <div>
        <img height="100px" src="<?php echo e(asset('imgs/email-notice.svg')); ?>" alt="Yortik logo">
    </div>
    <span style="font-size: x-large;">Email Verification!</span><br><br> 
    <p>
        You’ve received this message because your email address has been registered with yortik.com.
    </p>
    <p>
        Please click the button below to verify your email address and confirm your password to complete your registration.
    </p>
    <p style="color: #0d6efd;">
        Please note, your username is <b><?php echo e($mailData->username); ?></b>. 
    </p>
    <div class="p-2">
        <a href="<?php echo e(Request::root()); ?>/user/verify/<?php echo e($mailData->emailVerify->token); ?>" class="link-button">
            Verify Now
        </a>
    </div>
    <p>
        If you did not register with us, please disregard this email.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/mails/hello.blade.php ENDPATH**/ ?>