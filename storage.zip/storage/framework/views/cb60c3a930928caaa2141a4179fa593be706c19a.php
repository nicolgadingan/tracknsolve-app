

<?php $__env->startSection('page'); ?>
    New Ticket
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" id="tk-create-box">
    <div class="card card-body border-round border-forest-light pt-4">
        <div class="mb-2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tickets-create', ['tkey' => $tkey])->html();
} elseif ($_instance->childHasBeenRendered('PTgePBj')) {
    $componentId = $_instance->getRenderedChildComponentId('PTgePBj');
    $componentTag = $_instance->getRenderedChildComponentTagName('PTgePBj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PTgePBj');
} else {
    $response = \Livewire\Livewire::mount('tickets-create', ['tkey' => $tkey]);
    $html = $response->html();
    $_instance->logRenderedChild('PTgePBj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="mb-2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('upload-attachment', ['tkey' => $tkey])->html();
} elseif ($_instance->childHasBeenRendered('EE3p8Fm')) {
    $componentId = $_instance->getRenderedChildComponentId('EE3p8Fm');
    $componentTag = $_instance->getRenderedChildComponentTagName('EE3p8Fm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EE3p8Fm');
} else {
    $response = \Livewire\Livewire::mount('upload-attachment', ['tkey' => $tkey]);
    $html = $response->html();
    $_instance->logRenderedChild('EE3p8Fm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $("body").on("change", "select.must-select", function() {
                var thisObj = $(this);
                if (thisObj.children("option:selected").val() == "") {
                    thisObj.addClass("is-invalid");
                } else {
                    thisObj.removeClass("is-invalid");
                }
            });

            $("body").on("input", "#tk-assignment", function() {
                var thisObj = $(this);
                var inpAsgn = $("#tk-assignee");
                if (thisObj.val() == "") {
                    inpAsgn.val("");
                }
            });

            $("body").on("click", "#tk-create-submit", function() {
                $("#tk-create-form").submit();
            });

            // Delete attachment
            $("body").on("click", ".tk-del-att", function() {
                var attid   =   $(this).data('value'),
                    tarBtn  =   $("#tk-delatt-btn"),
                    tarInp  =   $("#tk-delatt-id");

                // $("#tk-delatt-id").val(attid, function() {
                //     tarBtn.trigger("click");
                // });

                tarInp.val(attid, function() {
                    tarBtn.trigger("click");
                    console.log("Trigger completed.");
                });
            });

            $("body").on("change", "#tk-assignment", function() {
                var grpId   =   $(this).val();
                $("#tk-selected-group").val(grpId);
            });
        });
    </script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/tickets/create.blade.php ENDPATH**/ ?>