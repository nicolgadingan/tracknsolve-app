

<?php $__env->startSection('page'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
        <div class="card card-body borderless shadow-sm border-bubble pb-2" id="box-login">
            <div class="center mb-3 p-2">
                <img src="<?php echo e(asset('imgs/yortik.svg')); ?>" alt="Yortik logo" id="brand-auth">
            </div>
            <?php echo $__env->make('plugins.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input type="text" id="li-username" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>"
                        class="form-control center borderless <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="li-username">Username</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" id="li-password" class="form-control center borderless" name="password" placeholder="Password">
                    <label for="li-password">Password</label>
                </div>
                <div class="mb-3">
                    <a href="#" class="link-marine">Forgot password?</a>
                </div>
                <div class="right">
                    <button type="submit" class="btn btn-lg btn-marine shadow">Login</button>
                </div>
            </form>
            <div class="pt-5 center">
                <small class="text-muted">
                    v<?php echo e(config('app.ver')); ?>

                </small>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/auth/login.blade.php ENDPATH**/ ?>