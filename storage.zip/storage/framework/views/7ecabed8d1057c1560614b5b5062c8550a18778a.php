

<?php $__env->startSection('page'); ?>
    Verify Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    This is your verification page.
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/users/verify.blade.php ENDPATH**/ ?>