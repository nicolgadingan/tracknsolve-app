
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Yortik')); ?> - <?php echo $__env->yieldContent('page'); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('imgs/yortik-icon.svg')); ?>" type="image/x-icon">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" crossorigin="anonymous"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
        integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB"
        crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
        integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
        crossorigin="anonymous"></script>

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <!-- Charting library -->
    <script src="https://unpkg.com/chart.js@^2.9.3/dist/Chart.min.js"></script>
    
    <!-- Chartisan -->
    <script src="https://unpkg.com/@chartisan/chartjs@^2.1.0/dist/chartisan_chartjs.umd.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"
        integrity="sha512-QSkVNOCYLtj73J4hbmVoOV6KVZuMluZlioC+trLpewV8qMjsWqlIQvkn1KGX2StWvPMdWGBqim1xlC8krl1EKQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="d-flex">
        <div id="sidebar" class="shadow-sm">
            <?php echo $__env->make('plugins.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="flex-grow-1 p-3 pb-5" id="context-body">
            <header class="container-fluid">
                <div class="row">
                    <div class="col-sm d-flex align-items-end fs-lg fg-marine-light">
                        <strong>
                            <?php
                                $path   =   explode("/", request()->path());
                                echo ucfirst($path[0]);
                            ?>
                        </strong>
                    </div>
                    <div class="col-auto">
                        <?php
                            $user   =   auth()->user();
                        ?>
                        <div class="dropdown">
                            <button class="btn btn-lg p-2 shadow dropdown-toggle btn-rose shadow" href="#" id="profile-link" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="true">
                                <b class="">
                                    <?php echo e(Str::ucfirst($user->first_name[0] . $user->last_name[0])); ?>

                                </b>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow pb-0" aria-labelledby="profile-link" id="profile-link-body">
                                <li class="right">
                                    <span class="dropdown-item-text">
                                        <b><?php echo e(Str::ucfirst($user->first_name . ' ' . $user->last_name)); ?></b><br>
                                        <span class="text-muted">
                                            <?php echo e(Str::ucfirst($user->role)); ?>

                                        </span>
                                    </span>
                                </li>
                                <li class="dropdown-divider"></li>
                                <li class="right">
                                    <a class="dropdown-item link-danger" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                </li>
                                <li class="right">
                                    <span class="dropdown-item-text">
                                        <small class="text-muted">
                                            v<?php echo e(config('app.ver')); ?>

                                        </small>
                                    </span>
                                </li>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </ul>
                        </div>
                        
                        <script>
                            var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
                            var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
                                return new bootstrap.Popover(popoverTriggerEl)
                            });
                            var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
                            var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
                                return new bootstrap.Dropdown(dropdownToggleEl);
                            });

                            $(document).ready(function() {
                                $("body").on("click", "#profile-link", function() {
                                    $("#profile-link-body").toggle("show");
                                });
                            });
                        </script>
                    </div>
                </div>
            </header>
            <main class="pt-5">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
    
    <script>
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
          return new bootstrap.Tooltip(tooltipTriggerEl)
        });
    </script>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>