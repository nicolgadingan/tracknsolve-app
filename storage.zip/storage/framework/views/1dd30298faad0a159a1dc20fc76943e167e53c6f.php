<div>
    <div class="d-flex align-items-center mb-2">
        <h6 class="fg-forest mb-0">
            ATTACHMENTS
        </h6>
        <span class="badge bg-cheese fg-marine fs-sm ml-2">
            <?php echo e(count($files)); ?>

        </span>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <?php if($status != 'closed'): ?>
                <div class="mb-3">
                    <form wire:submit.prevent="save">
                        <div class="row g-3">
                            <div class="col-sm">
                                <input type="hidden" wire:model="tkey" value="<?php echo e($tkey); ?>">
                                <div class="has-icon has-icon-end">
                                    <input type="file" class="form-control has-icon-form <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tk-attachment"
                                        aria-describedby="attachment-button" aria-label="Upload" name="attachment" wire:model="attachment">
                                    <?php $__errorArgs = ['attachment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div wire:loading wire:target="attachment" class="spinner-grow spinner-grow-sm has-icon-this" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary" type="submit" id="attachment-button" <?php echo e(($attachment == '') ? 'disabled' : ''); ?>>
                                    Upload
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
            <div class="mb-3">
                <?php if(count($files) > 0): ?>
                    <input type="hidden" wire:model="xfile" id="tk-delatt-id">
                    <button class="d-none" wire:click="delatt" id="tk-delatt-btn" ></button>
                    <ul class="list-group">
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <a href="<?php echo e(asset('storage/' . $file->att_path)); ?>" class="link-primary" download="<?php echo e($file->att_path); ?>">
                                    <?php echo e(Arr::last(explode('/', $file->att_path))); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    No attachments
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\yortik-app\resources\views/livewire/upload-attachment.blade.php ENDPATH**/ ?>