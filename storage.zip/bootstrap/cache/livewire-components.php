<?php return array (
  'groups-create' => 'App\\Http\\Livewire\\GroupsCreate',
  'groups-edit' => 'App\\Http\\Livewire\\GroupsEdit',
  'groups-index' => 'App\\Http\\Livewire\\GroupsIndex',
  'tickets-comments' => 'App\\Http\\Livewire\\TicketsComments',
  'tickets-create' => 'App\\Http\\Livewire\\TicketsCreate',
  'tickets-edit' => 'App\\Http\\Livewire\\TicketsEdit',
  'tickets-get-users' => 'App\\Http\\Livewire\\TicketsGetUsers',
  'tickets-index' => 'App\\Http\\Livewire\\TicketsIndex',
  'upload-attachment' => 'App\\Http\\Livewire\\UploadAttachment',
  'users-edit' => 'App\\Http\\Livewire\\UsersEdit',
  'users-search-user' => 'App\\Http\\Livewire\\UsersSearchUser',
);