@extends('layouts.app')

@section('page')
    Settings
@endsection

@section('content')
<div class="container-fluids">
    This is your Settings page
</div>
@endsection