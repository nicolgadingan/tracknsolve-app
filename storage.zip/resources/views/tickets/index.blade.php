@extends('layouts.app')

@section('page')
    Tickets
@endsection

@section('content')
    @livewire('tickets-index')
@endsection