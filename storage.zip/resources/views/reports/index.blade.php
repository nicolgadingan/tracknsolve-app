@extends('layouts.app')

@section('page')
    Reports
@endsection

@section('content')
<div class="container-fluids">
    This is your Reports page
</div>
@endsection