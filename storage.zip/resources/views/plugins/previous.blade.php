<div class="">
    <a href="{{ $path }}" class="display-6 link-secondary">
        <i class="bi bi-arrow-left-square-fill"></i>
    </a>
    {{-- <a href="{{ url()->previous() }}" class="fs-xl pb-1">
        <i class="bi bi-arrow-left-square-fill"></i>
    </a> --}}
</div>